vipHashes = []
adminHashes = []
ownerHashes =[]
